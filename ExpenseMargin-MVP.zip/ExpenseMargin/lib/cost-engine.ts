export type PricePoint = {
  quantity: number;
  lineTotal: number;
};

export function normalizedUnitCost(point: PricePoint): number {
  if (point.quantity <= 0) throw new Error("Quantity must be greater than zero");
  return point.lineTotal / point.quantity;
}

export function percentChange(previous: number, current: number): number {
  if (previous <= 0) throw new Error("Previous cost must be greater than zero");
  return ((current - previous) / previous) * 100;
}

export function annualizedImpact(previousUnitCost: number, currentUnitCost: number, monthlyQuantity: number): number {
  return Math.max(0, currentUnitCost - previousUnitCost) * Math.max(0, monthlyQuantity) * 12;
}

export function isMeaningfulIncrease(previous: number, current: number, thresholdPercent = 5): boolean {
  return percentChange(previous, current) >= thresholdPercent;
}
