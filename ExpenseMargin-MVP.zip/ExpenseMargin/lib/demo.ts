export const demoChanges = [
  { item: "Nitrile Gloves — Large", supplier: "ABC Supply", oldPrice: 72.0, newPrice: 84.0, change: 16.7, annualImpact: 2880 },
  { item: "Paper Towels — 12 Pack", supplier: "SupplyCo", oldPrice: 38.5, newPrice: 46.25, change: 20.1, annualImpact: 2232 },
  { item: "Disinfectant — 1 gal", supplier: "CleanSource", oldPrice: 24.1, newPrice: 27.8, change: 15.4, annualImpact: 1332 },
  { item: "Shipping Boxes — Medium", supplier: "PackRight", oldPrice: 0.88, newPrice: 0.97, change: 10.2, annualImpact: 972 },
];

export const demoSuppliers = [
  { name: "ABC Supply", invoices: 14, spend: 18420, alerts: 6 },
  { name: "SupplyCo", invoices: 11, spend: 12840, alerts: 4 },
  { name: "CleanSource", invoices: 8, spend: 6240, alerts: 2 },
  { name: "PackRight", invoices: 9, spend: 5180, alerts: 3 },
];
