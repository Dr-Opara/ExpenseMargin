import fs from "node:fs";
import path from "node:path";

const required = [
  "package.json",
  "app/page.tsx",
  "app/dashboard/page.tsx",
  "app/invoices/page.tsx",
  "app/login/page.tsx",
  "app/signup/page.tsx",
  "app/onboarding/page.tsx",
  "app/api/invoices/upload/route.ts",
  "lib/cost-engine.ts",
  "supabase/migrations/001_initial_schema.sql",
  "supabase/migrations/002_onboarding_and_storage.sql",
  ".env.example",
];

const missing = required.filter((file) => !fs.existsSync(path.resolve(file)));
if (missing.length) {
  console.error("Missing required files:", missing);
  process.exit(1);
}
const packageJson = JSON.parse(fs.readFileSync("package.json", "utf8"));
for (const script of ["dev", "build", "start", "typecheck"]) {
  if (!packageJson.scripts?.[script]) throw new Error(`Missing npm script: ${script}`);
}
console.log(`Project structure check passed (${required.length} critical files).`);
