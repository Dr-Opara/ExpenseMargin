function unitCost(quantity, total) {
  if (quantity <= 0) throw new Error("quantity");
  return total / quantity;
}
function pct(previous, current) {
  if (previous <= 0) throw new Error("previous");
  return ((current - previous) / previous) * 100;
}
function annual(previous, current, monthlyQty) {
  return Math.max(0, current - previous) * Math.max(0, monthlyQty) * 12;
}
const oldUnit = unitCost(24, 120);
const newUnit = unitCost(20, 116);
if (oldUnit !== 5) throw new Error("Old unit cost failed");
if (Math.abs(newUnit - 5.8) > 1e-9) throw new Error("New unit cost failed");
if (Math.abs(pct(oldUnit, newUnit) - 16) > 1e-9) throw new Error("Percent change failed");
if (Math.abs(annual(72, 84, 20) - 2880) > 1e-9) throw new Error("Annual impact failed");
console.log("Cost engine validation passed");
