# Development checklist

## Required accounts before live integration testing
- Supabase project
- OpenAI API project/key
- Vercel project (deployment phase)
- Resend account (alerts phase)
- Stripe account (billing phase)

## Setup
```bash
npm install
cp .env.example .env.local
npm run dev
```

Run SQL migrations in order:
1. `supabase/migrations/001_initial_schema.sql`
2. `supabase/migrations/002_onboarding_and_storage.sql`
3. `supabase/migrations/003_product_uniqueness.sql`

## Validation
```bash
node scripts/project-check.mjs
node scripts/validate-cost-engine.mjs
npm run typecheck
npm run build
```

`npm install`, `typecheck`, and `build` require package registry access. The ChatGPT runtime used to create this initial scaffold could not complete npm dependency download, so those two framework-level validations must run in Codespaces/local/Vercel after dependencies are installed.
