import { demoChanges } from "@/lib/demo";

export function PriceChangeTable() {
  return (
    <div className="table-wrap">
      <table>
        <thead><tr><th>Item</th><th>Supplier</th><th>Previous</th><th>Current</th><th>Change</th><th>Annual impact</th></tr></thead>
        <tbody>
          {demoChanges.map((row) => (
            <tr key={row.item}>
              <td><strong>{row.item}</strong></td>
              <td>{row.supplier}</td>
              <td>${row.oldPrice.toFixed(2)}</td>
              <td>${row.newPrice.toFixed(2)}</td>
              <td><span className="badge bad">+{row.change}%</span></td>
              <td><strong>+${row.annualImpact.toLocaleString()}</strong></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
