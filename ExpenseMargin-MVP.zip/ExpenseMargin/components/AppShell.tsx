import Link from "next/link";

const links = [
  ["Dashboard", "/dashboard"],
  ["Invoices", "/invoices"],
  ["Suppliers", "/suppliers"],
  ["Products", "/products"],
  ["Alerts", "/alerts"],
];

export function AppShell({ children, active }: { children: React.ReactNode; active: string }) {
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <Link href="/dashboard" className="brand">
          <span className="brand-mark">EM</span>
          <span>ExpenseMargin</span>
        </Link>
        <nav className="side-nav">
          {links.map(([label, href]) => (
            <Link key={href} href={href} className={`side-link ${active === label ? "active" : ""}`}>
              {label}
            </Link>
          ))}
        </nav>
        <div className="side-footer">Track expenses. Protect margins.</div>
      </aside>
      <main className="main">
        <div className="topbar">
          <div><strong>Acme Business</strong></div>
          <Link href="/invoices" className="btn primary">Upload invoices</Link>
        </div>
        {children}
      </main>
    </div>
  );
}
