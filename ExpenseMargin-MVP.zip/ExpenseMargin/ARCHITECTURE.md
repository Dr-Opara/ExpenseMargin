# ExpenseMargin Architecture

## Product promise
Upload supplier invoices and see which recurring costs are increasing and how much those increases could cost annually.

## Current request path
1. User authenticates with Supabase Auth.
2. User creates an organization workspace through `create_organization` RPC.
3. Invoice upload API validates MIME type and 12 MB size limit.
4. Invoice is stored in a private `invoices` bucket under `<organization>/<invoice>/<file>`.
5. Extraction API downloads the private file server-side.
6. File is temporarily sent to OpenAI for structured invoice extraction.
7. Structured output is validated with Zod.
8. Supplier and product names are normalized and persisted.
9. Prior product cost is retrieved.
10. Application code calculates unit cost, percentage change, and annualized impact.
11. Increases of 5%+ create a cost alert.
12. The temporary OpenAI file is deleted after processing.

## Security boundaries
- Supabase RLS isolates organization data.
- Invoice storage bucket is private.
- API keys stay server-side.
- Uploads are restricted by file type and size.
- Browser never receives service-role credentials or the OpenAI key.

## Phase status
### Phase 1 — Foundation: BUILT
- Next.js app shell
- responsive landing/dashboard
- Supabase multi-tenant schema
- authentication pages
- organization onboarding
- secure invoice upload

### Phase 2 — Invoice intelligence: BUILT, requires live credentials for integration testing
- OpenAI file input
- strict structured invoice extraction
- Zod validation
- supplier/product persistence
- deterministic price-change engine
- cost alerts

### Phase 3 — Next
- stronger product matching using SKU + aliases + embedding similarity
- human review screen for uncertain matches/extraction
- real dashboard queries instead of demo seed data
- background job queue rather than synchronous browser processing
- Resend alerts and weekly digest

### Phase 4
- Stripe plans and invoice-processing limits
- PostHog and Sentry
- rate limiting / abuse controls
- production deployment to Vercel
