# ExpenseMargin

**Track expenses. Protect margins.**

ExpenseMargin is a B2B cost-intelligence SaaS that compares recurring supplier invoice line items, detects unit-cost increases, and estimates the monthly and annual impact on business margins.

## MVP scope

- Responsive marketing page and desktop-first SaaS dashboard
- Invoice upload UI for PDF/JPG/PNG
- Suppliers, products, alerts, and price-change views
- Deterministic cost engine for unit normalization, percentage change, and annual impact
- Supabase-ready multi-tenant schema with Row Level Security
- OpenAI extraction endpoint placeholder for Phase 2

## Local setup

1. Install dependencies:
   `npm install`
2. Copy environment variables:
   `cp .env.example .env.local`
3. Run:
   `npm run dev`
4. Open `http://localhost:3000`

## Planned next phase

1. Supabase authentication and organization onboarding
2. Secure private invoice storage
3. OpenAI structured invoice extraction
4. SKU/text/semantic product matching
5. Cost-alert persistence and email notifications
6. Stripe subscription billing

## Core principle

AI interprets messy invoice data; deterministic application code performs all financial calculations.
