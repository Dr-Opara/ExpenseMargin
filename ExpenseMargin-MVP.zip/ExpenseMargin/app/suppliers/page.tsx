import { AppShell } from "@/components/AppShell";
import { demoSuppliers } from "@/lib/demo";

export default function SuppliersPage() {
  return (
    <AppShell active="Suppliers"><div className="page"><div className="page-head"><div><h1>Suppliers</h1><p>Monitor recurring spend and price changes by vendor.</p></div></div><section className="panel" style={{marginTop:0}}><div className="table-wrap"><table><thead><tr><th>Supplier</th><th>Invoices</th><th>Tracked spend</th><th>Active alerts</th></tr></thead><tbody>{demoSuppliers.map((s)=><tr key={s.name}><td><strong>{s.name}</strong></td><td>{s.invoices}</td><td>${s.spend.toLocaleString()}</td><td>{s.alerts ? <span className="badge bad">{s.alerts}</span> : <span className="badge good">0</span>}</td></tr>)}</tbody></table></div></section></div></AppShell>
  );
}
