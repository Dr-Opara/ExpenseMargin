import { AppShell } from "@/components/AppShell";
import { demoChanges } from "@/lib/demo";

export default function AlertsPage() {
  return <AppShell active="Alerts"><div className="page"><div className="page-head"><div><h1>Alerts</h1><p>Review the cost changes most likely to affect your margin.</p></div></div><div style={{display:"grid",gap:12}}>{demoChanges.map((a)=><section className="metric" key={a.item}><div style={{display:"flex",justifyContent:"space-between",gap:18}}><div><div className="metric-label">{a.supplier}</div><div style={{fontWeight:800,fontSize:18,marginTop:5}}>{a.item}</div><div className="metric-note">${a.oldPrice.toFixed(2)} → ${a.newPrice.toFixed(2)} · estimated +${a.annualImpact.toLocaleString()}/year</div></div><span className="badge bad">+{a.change}%</span></div></section>)}</div></div></AppShell>;
}
