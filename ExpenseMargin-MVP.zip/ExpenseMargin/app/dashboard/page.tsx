import { AppShell } from "@/components/AppShell";
import { MetricCard } from "@/components/MetricCard";
import { PriceChangeTable } from "@/components/PriceChangeTable";

export default function DashboardPage() {
  return (
    <AppShell active="Dashboard">
      <div className="page">
        <div className="page-head"><div><h1>Cost overview</h1><p>Supplier cost movement and estimated margin impact.</p></div></div>
        <div className="grid-4">
          <MetricCard label="Potential annual cost increase" value="$8,416" note="Across 15 detected changes" />
          <MetricCard label="Price increases detected" value="15" note="4 new this week" />
          <MetricCard label="Suppliers monitored" value="4" note="42 invoices analyzed" />
          <MetricCard label="Costs held steady" value="87%" note="Most tracked items unchanged" tone="good" />
        </div>
        <section className="panel"><div className="panel-head"><h2>Biggest cost changes</h2><span className="badge warn">Needs review</span></div><PriceChangeTable /></section>
      </div>
    </AppShell>
  );
}
