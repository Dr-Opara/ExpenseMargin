import OpenAI from "openai";
import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { extractedInvoiceSchema } from "@/lib/types/invoice";
import { annualizedImpact, normalizedUnitCost, percentChange } from "@/lib/cost-engine";
import { normalizeText } from "@/lib/normalize";

const invoiceSchema = {
  type: "object",
  additionalProperties: false,
  required: ["supplier", "invoiceNumber", "invoiceDate", "currency", "subtotal", "fees", "tax", "total", "items"],
  properties: {
    supplier: { type: "string" },
    invoiceNumber: { anyOf: [{ type: "string" }, { type: "null" }] },
    invoiceDate: { type: "string", description: "ISO date YYYY-MM-DD" },
    currency: { type: "string", minLength: 3, maxLength: 3 },
    subtotal: { anyOf: [{ type: "number" }, { type: "null" }] },
    fees: { type: "number" },
    tax: { type: "number" },
    total: { type: "number" },
    items: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        required: ["sku", "description", "quantity", "unit", "unitPrice", "lineTotal"],
        properties: {
          sku: { anyOf: [{ type: "string" }, { type: "null" }] },
          description: { type: "string" },
          quantity: { type: "number" },
          unit: { anyOf: [{ type: "string" }, { type: "null" }] },
          unitPrice: { type: "number" },
          lineTotal: { type: "number" },
        },
      },
    },
  },
} as const;

export async function POST(request: Request) {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return NextResponse.json({ error: "OPENAI_API_KEY is not configured" }, { status: 503 });

  const body = await request.json().catch(() => ({}));
  const invoiceId = typeof body.invoiceId === "string" ? body.invoiceId : "";
  if (!invoiceId) return NextResponse.json({ error: "invoiceId is required" }, { status: 400 });

  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { data: invoice, error: invoiceError } = await supabase
    .from("invoices")
    .select("id, organization_id, storage_path")
    .eq("id", invoiceId)
    .single();
  if (invoiceError || !invoice?.storage_path) return NextResponse.json({ error: "Invoice not found" }, { status: 404 });

  await supabase.from("invoices").update({ status: "processing" }).eq("id", invoiceId);

  const { data: blob, error: downloadError } = await supabase.storage.from("invoices").download(invoice.storage_path);
  if (downloadError || !blob) {
    await supabase.from("invoices").update({ status: "failed" }).eq("id", invoiceId);
    return NextResponse.json({ error: "Could not read invoice file" }, { status: 500 });
  }

  const fileName = invoice.storage_path.split("/").pop() || "invoice.pdf";
  const openai = new OpenAI({ apiKey });
  let uploadedFileId: string | null = null;

  try {
    const file = new File([await blob.arrayBuffer()], fileName, { type: blob.type || "application/pdf" });
    const uploaded = await openai.files.create({ file, purpose: "user_data" });
    uploadedFileId = uploaded.id;

    const response = await openai.responses.create({
      model: "gpt-5.6-luna",
      reasoning: { effort: "none" },
      input: [{
        role: "user",
        content: [
          { type: "input_file", file_id: uploaded.id },
          { type: "input_text", text: "Extract this supplier invoice. Preserve the supplier's exact product descriptions and SKUs when present. Quantity must represent the billed quantity, unitPrice the stated price per billed unit, and lineTotal the billed line total. Put shipping, fuel, delivery, handling, or service charges into fees when they are invoice-level charges. Return only the required structured data." },
        ],
      }],
      text: {
        format: {
          type: "json_schema",
          name: "expensemargin_invoice",
          strict: true,
          schema: invoiceSchema,
        },
      },
    });

    const parsed = extractedInvoiceSchema.parse(JSON.parse(response.output_text));
    const normalizedSupplier = normalizeText(parsed.supplier);

    const { data: supplier, error: supplierError } = await supabase
      .from("suppliers")
      .upsert({ organization_id: invoice.organization_id, name: parsed.supplier, normalized_name: normalizedSupplier }, { onConflict: "organization_id,normalized_name" })
      .select("id")
      .single();
    if (supplierError || !supplier) throw new Error("Could not save supplier");

    await supabase.from("invoices").update({
      supplier_id: supplier.id,
      invoice_number: parsed.invoiceNumber,
      invoice_date: parsed.invoiceDate,
      currency: parsed.currency.toUpperCase(),
      subtotal: parsed.subtotal,
      fees: parsed.fees,
      tax: parsed.tax,
      total: parsed.total,
    }).eq("id", invoiceId);

    const alertsCreated: string[] = [];

    for (const item of parsed.items) {
      const normalizedName = normalizeText(item.description);
      const { data: product, error: productError } = await supabase
        .from("products")
        .upsert({ organization_id: invoice.organization_id, normalized_name: normalizedName, sku: item.sku }, { onConflict: "organization_id,normalized_name" })
        .select("id")
        .single();
      if (productError || !product) throw new Error(`Could not save product: ${item.description}`);

      const currentUnitCost = normalizedUnitCost({ quantity: item.quantity, lineTotal: item.lineTotal });
      const { data: previousRows } = await supabase
        .from("invoice_items")
        .select("quantity,line_total,created_at")
        .eq("organization_id", invoice.organization_id)
        .eq("product_id", product.id)
        .order("created_at", { ascending: false })
        .limit(1);

      await supabase.from("invoice_items").insert({
        organization_id: invoice.organization_id,
        invoice_id: invoiceId,
        supplier_id: supplier.id,
        product_id: product.id,
        raw_description: item.description,
        sku: item.sku,
        quantity: item.quantity,
        unit: item.unit,
        unit_price: item.unitPrice,
        line_total: item.lineTotal,
        match_confidence: item.sku ? 1 : 0.9,
      });

      const previous = previousRows?.[0];
      if (!previous) continue;
      const previousUnitCost = normalizedUnitCost({ quantity: Number(previous.quantity), lineTotal: Number(previous.line_total) });
      const change = percentChange(previousUnitCost, currentUnitCost);
      if (change < 5) continue;

      const annualImpact = annualizedImpact(previousUnitCost, currentUnitCost, item.quantity);
      const { data: alert } = await supabase.from("cost_alerts").insert({
        organization_id: invoice.organization_id,
        supplier_id: supplier.id,
        product_id: product.id,
        previous_unit_cost: previousUnitCost,
        current_unit_cost: currentUnitCost,
        percent_change: change,
        estimated_monthly_impact: annualImpact / 12,
        estimated_annual_impact: annualImpact,
      }).select("id").single();
      if (alert?.id) alertsCreated.push(alert.id);
    }

    await supabase.from("invoices").update({ status: "complete" }).eq("id", invoiceId);
    return NextResponse.json({ invoiceId, status: "complete", items: parsed.items.length, alertsCreated: alertsCreated.length });
  } catch (error) {
    await supabase.from("invoices").update({ status: "review_required" }).eq("id", invoiceId);
    return NextResponse.json({ error: error instanceof Error ? error.message : "Invoice extraction failed" }, { status: 422 });
  } finally {
    if (uploadedFileId) await openai.files.delete(uploadedFileId).catch(() => undefined);
  }
}
