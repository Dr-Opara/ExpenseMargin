import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

const MAX_FILE_SIZE = 12 * 1024 * 1024;
const allowedTypes = new Set(["application/pdf", "image/png", "image/jpeg"]);

export async function POST(request: Request) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const formData = await request.formData();
  const file = formData.get("file");
  if (!(file instanceof File)) return NextResponse.json({ error: "File is required" }, { status: 400 });
  if (!allowedTypes.has(file.type)) return NextResponse.json({ error: "Unsupported file type" }, { status: 415 });
  if (file.size > MAX_FILE_SIZE) return NextResponse.json({ error: "File exceeds 12 MB limit" }, { status: 413 });

  const { data: memberships, error: membershipError } = await supabase
    .from("organization_members")
    .select("organization_id")
    .eq("user_id", user.id)
    .limit(1);
  if (membershipError || !memberships?.[0]) return NextResponse.json({ error: "No organization found for user" }, { status: 409 });

  const organizationId = memberships[0].organization_id;
  const { data: invoice, error: invoiceError } = await supabase
    .from("invoices")
    .insert({ organization_id: organizationId, status: "uploaded" })
    .select("id")
    .single();
  if (invoiceError || !invoice) return NextResponse.json({ error: "Could not create invoice record" }, { status: 500 });

  const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
  const path = `${organizationId}/${invoice.id}/${safeName}`;
  const bytes = await file.arrayBuffer();
  const { error: uploadError } = await supabase.storage.from("invoices").upload(path, bytes, { contentType: file.type, upsert: false });
  if (uploadError) {
    await supabase.from("invoices").update({ status: "failed" }).eq("id", invoice.id);
    return NextResponse.json({ error: "Could not store invoice" }, { status: 500 });
  }

  await supabase.from("invoices").update({ storage_path: path, status: "queued" }).eq("id", invoice.id);
  return NextResponse.json({ invoiceId: invoice.id, status: "queued" }, { status: 201 });
}
