import { AppShell } from "@/components/AppShell";
import { PriceChangeTable } from "@/components/PriceChangeTable";

export default function ProductsPage() {
  return <AppShell active="Products"><div className="page"><div className="page-head"><div><h1>Products</h1><p>Normalized item-level cost history across supplier invoices.</p></div></div><section className="panel" style={{marginTop:0}}><PriceChangeTable /></section></div></AppShell>;
}
