import { AppShell } from "@/components/AppShell";
import { UploadDropzone } from "@/components/UploadDropzone";

export default function InvoicesPage() {
  return (
    <AppShell active="Invoices">
      <div className="page">
        <div className="page-head"><div><h1>Invoices</h1><p>Upload supplier invoices to build a cost history.</p></div></div>
        <div className="split">
          <section className="panel" style={{ marginTop: 0 }}><div className="panel-head"><h2>Upload invoices</h2></div><div style={{ padding: 20 }}><UploadDropzone /></div></section>
          <section className="panel" style={{ marginTop: 0 }}><div className="panel-head"><h2>How analysis works</h2></div><div style={{ padding: 20, lineHeight: 1.7, color: "#4b5563" }}><ol><li>Extract supplier, invoice date, SKU, quantity, unit price, fees, and totals.</li><li>Match repeated products across invoices.</li><li>Normalize unit cost and compare historical pricing.</li><li>Flag meaningful increases and estimate annual impact.</li></ol></div></section>
        </div>
      </div>
    </AppShell>
  );
}
